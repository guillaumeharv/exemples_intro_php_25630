<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Exercice 1 : La somme des 25 premiers entiers</h1>
    <?php 
/*
    Faire une boucle while qui calcule et affiche la somme des entiers compris entre 1 et 25.  
    1 + 2 + 3 + 4... + 23 + 24 + 25 = ? 
*/
    $somme = 0;
    $i = 1;

    //tant que i est plus petit ou égal à 25
    while($i <= 25)
    {
        //on ajoute i dans la somme
        //$somme = $somme + $i; //équivalent
        $somme += $i; 
        $i++;//instruction qui nous rapproche de la sortie
    }

    echo "La somme des entiers compris entre 1 et 25 est $somme.";
?>
    <h1>Exercice 2 : La table des multiples de 3</h1>
    <h1>Exercice 3 : La somme maximale de 1000</h1>
    <?php 
    $i = 0;
    $somme = 0;
    $somme_a_atteindre = 1000;

    do 
    {
        $i++;
        $somme += $i;
        echo "\$i a comme valeur $i, la somme a comme valeur $somme<br>";
    }
    while($somme < $somme_a_atteindre);

    echo "Il faut se rendre jusqu'à n = $i dans la suite 1 + 2 + 3 + 4 + ... + n pour atteindre la somme de $somme_a_atteindre.";

    ?>
</body>
</html>