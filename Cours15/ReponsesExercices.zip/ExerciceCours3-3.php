<?php 
      $action = "produit";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Avec le if/else</h1>
    <?php 
        //avec la structure if/else if/else 
        if($action == "accueil")
        {
            echo "<h1>Bonjour, bienvenue sur notre site.</h1>";
        }
        else if($action == "produit")
        {
        ?>
        <ul>
            <li>Nintendo Switch 2</li>
            <li>Sony Playstation 5</li>
            <li>Une grosse TV</li>
        </ul>
        <?php
        }
        else 
        {
            echo "Erreur 404, pas de traitement pour cette action.";
        }
    ?>
    <h1>Avec le switch/case</h1>
    <?php
       //avec la structure if/else if/else 
        switch($action)
        {
            case "accueil":
                echo "<h1>Bonjour, bienvenue sur notre site.</h1>";
                break;
            case "produit":
            ?>
                <ul>
                    <li>Nintendo Switch 2</li>
                    <li>Sony Playstation 5</li>
                    <li>Une grosse TV</li>
                </ul>
            <?php
                break;
            default: 
                echo "Erreur 404, pas de traitement pour cette action.";
        }
    ?>
</body>
</html>